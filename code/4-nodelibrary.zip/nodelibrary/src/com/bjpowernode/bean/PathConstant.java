package com.bjpowernode.bean;

/*
    ·��������
 */
public class PathConstant {
    public static final String USER_PATH = "user/user.txt";
    public static final String BOOK_PATH = "book/book.txt";
    public static final String LEND_PATH = "lend/lend.txt";
}
