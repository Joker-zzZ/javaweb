package com.bjpowernode.service;

import java.util.Map;

public interface ChartService {
    Map<String, Integer> bookTypeCount();
}
