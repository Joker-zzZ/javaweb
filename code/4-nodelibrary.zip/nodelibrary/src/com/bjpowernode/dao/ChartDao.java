package com.bjpowernode.dao;

import java.util.Map;

public interface ChartDao {
    Map<String, Integer> bookTypeCount();
}
